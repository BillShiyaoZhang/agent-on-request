Agent on Request - visual materials

3 pages: project diagrams (2) + interaction storyboard (1).
pdf/ - combined and split PDFs
boards/ - individual 150-dpi PNGs
materials-preview.png - overview
build_materials.py - editable vector source (uv + reportlab/pypdf)

Schematic controls; fictional Guided example.
The original textual notes and real captures remain separately in the repository;
they are not included in this visual presentation package.
